const { test } = require('node:test');
const assert = require('node:assert/strict');
const { DEFAULTS, completionUrl, validateConfig, cropBounds, StableFrames, frameChanged, redact } = require('../src/core');
test('API address normalization and credential transport restrictions', () => {
  assert.equal(completionUrl(' https://example.com/v1/ '), 'https://example.com/v1/chat/completions');
  assert.equal(completionUrl('https://example.com/v1/chat/completions'), 'https://example.com/v1/chat/completions');
  assert.equal(completionUrl('http://127.0.0.1:3456/v1'), 'http://127.0.0.1:3456/v1/chat/completions');
  for (const bad of ['http://remote.example/v1', 'https://name:secret@example.com', 'https://example.com?a=1', 'file:///etc']) assert.throws(() => completionUrl(bad));
});
test('configuration is bounded, permits no persisted plaintext key and validates region', () => {
  const config = validateConfig({ intervalMs: 1, cooldownMs: Infinity, maxTokens: 999999, apiKey: 'secret', region: null });
  assert.equal(config.intervalMs, 1000); assert.equal(config.maxTokens, 16384);
  assert.equal(config.cooldownMs, DEFAULTS.cooldownMs); assert.equal(config.apiKey, undefined);
  assert.throws(() => validateConfig({ region: { x: 0, y: 0, width: 2, height: 20 } }));
});
test('crop coordinates follow actual thumbnail scale, including fractional DPI', () => {
  assert.deepEqual(cropBounds({ width: 2560, height: 1440 }, { width: 2048, height: 1152 }, { x: 120, y: 200, width: 800, height: 400 }), { x: 150, y: 250, width: 1000, height: 500 });
  assert.throws(() => cropBounds({ width: 1920, height: 1080 }, { width: 1920, height: 1080 }, { x: 1500, y: 0, width: 800, height: 300 }));
});
test('two stable frames trigger once, scrolling does not trigger and changed question retriggers', () => {
  const f = new StableFrames(), a = new Uint8Array(10000).fill(200), b = new Uint8Array(10000).fill(100);
  assert.equal(f.observe(a), false); assert.equal(f.observe(b), false);
  assert.equal(f.observe(b), true); f.accept(b); assert.equal(f.observe(b), false);
  assert.equal(f.observe(a), false); assert.equal(f.observe(a), true);
  f.reset(); assert.equal(f.observe(a), false);
});
test('minor capture noise is ignored and localized text changes are detected', () => {
  const a = new Uint8Array(10000).fill(200), noise = a.map(v => v + 1), text = a.slice();
  text.fill(40, 300, 340);
  assert.equal(frameChanged(a, noise), false); assert.equal(frameChanged(a, text), true);
  assert.equal(redact('secret Bearer abc', 'secret').includes('secret'), false);
});
