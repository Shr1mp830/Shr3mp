const { test } = require('node:test');
const assert = require('node:assert/strict');
const { requestQwen, readSSE } = require('../src/qwen');
const { DEFAULTS } = require('../src/core');
async function* chunks(text, size = 3) { const bytes = new TextEncoder().encode(text); for (let i = 0; i < bytes.length; i += size) yield bytes.slice(i, i + size); }
test('SSE handles split UTF-8, CRLF, comments, multiple data lines and final event', async () => {
  const input = ': keepalive\r\ndata: 第一行\r\ndata: 第二行\r\n\r\ndata: [DONE]';
  const events = []; for await (const event of readSSE(chunks(input, 1))) events.push(event);
  assert.deepEqual(events, ['第一行\n第二行', '[DONE]']);
});
test('visual request contains image and model, streams partial answers without reasoning', async () => {
  let body; const updates = [];
  const response = new Response('data: {"choices":[{"delta":{"reasoning_content":"不要显示"}}]}\n\ndata: {"choices":[{"delta":{"content":"答案"}}]}\n\ndata: {"choices":[{"delta":{"content":"是 42"},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n', { headers: { 'Content-Type': 'text/event-stream' } });
  const result = await requestQwen({ config: DEFAULTS, key: 'test-key', imageUrl: 'data:image/jpeg;base64,AAAA', onText: text => updates.push(text), fetchImpl: async (_url, options) => { body = JSON.parse(options.body); assert.equal(options.redirect, 'error'); return response; } });
  assert.equal(body.model, 'qwen3.8-max'); assert.equal(body.enable_thinking, false);
  assert.equal(body.messages[1].content[0].type, 'image_url');
  assert.equal(result, '答案是 42'); assert.deepEqual(updates, ['答案', '答案是 42']);
});
test('401 errors redact returned credentials', async () => {
  await assert.rejects(requestQwen({ config: DEFAULTS, key: 'super-secret', testOnly: true, fetchImpl: async () => new Response('{"error":{"message":"bad super-secret"}}', { status: 401 }) }), error => error.status === 401 && !error.message.includes('super-secret'));
});
test('cancelled requests propagate cancellation', async () => {
  const controller = new AbortController(); controller.abort();
  await assert.rejects(requestQwen({ config: DEFAULTS, key: 'test', signal: controller.signal, fetchImpl: async (_url, options) => { options.signal.throwIfAborted(); } }), { name: 'AbortError' });
});
test('truncated streams fail clearly instead of accepting partial answers', async () => {
  await assert.rejects(requestQwen({ config: DEFAULTS, key: 'test', fetchImpl: async () => new Response('data: {"choices":[{"delta":{"content":"partial"}}]}\n\n', { headers: { 'Content-Type': 'text/event-stream' } }) }), /连接提前中断/);
});
test('JSON fallback works and length limit is visible', async () => {
  const answer = await requestQwen({ config: DEFAULTS, key: 'test', fetchImpl: async () => Response.json({ choices: [{ message: { content: '答案' }, finish_reason: 'length' }] }) });
  assert.match(answer, /长度限制/);
});
