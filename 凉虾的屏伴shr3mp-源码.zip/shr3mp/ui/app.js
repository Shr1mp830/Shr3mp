'use strict';
const api = window.companion, $ = id => document.getElementById(id);
let state, initialized = false, lastAnswer, toastTimer;
function toast(text) { $('toast').textContent = text; $('toast').hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').hidden = true, 5000); }
async function call(method, ...args) { const result = await api[method](...args); if (!result.ok) { toast(result.error); throw new Error(result.error); } return result.value; }
function switchPage(page) {
  document.querySelectorAll('.page').forEach(el => el.classList.toggle('active', el.id === 'page-' + page));
  document.querySelectorAll('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.page === page));
}
function toggle(id, on) { $(id).classList.toggle('on', on); $(id).setAttribute('aria-checked', String(on)); }
function fillSettings(s) {
  $('base-url').value = s.config.baseUrl; $('model').value = s.config.model;
  $('interval').value = s.config.intervalMs; $('cooldown').value = s.config.cooldownMs;
  $('max-tokens').value = s.config.maxTokens; $('opacity').value = Math.round(s.config.opacity * 100);
  $('opacity-label').value = $('opacity').value + '%';
  $('display').replaceChildren(...s.displays.map(d => { const option = document.createElement('option'); option.value = d.id; option.textContent = d.label + ' · ' + d.width + ' × ' + d.height; return option; }));
  $('display').value = s.config.displayId || s.displays[0]?.id;
}
function render(s) {
  state = s;
  if (!initialized) { fillSettings(s); initialized = true; }
  $('status-text').textContent = s.status;
  $('status-dot').classList.toggle('active', s.running || s.phase === 'solving');
  $('status-detail').textContent = !s.hasKey ? '先连接 Qwen 视觉模型，再框选屏幕中的题面。' : !s.config.region ? '模型已配置，请框选完整的题目区域。' : s.running ? '画面稳定后自动识别，你可以继续使用原窗口。' : '区域已就绪。开始监听，或立即识别一次。';
  $('start').textContent = s.running ? '暂停自动识别 Ⅱ' : '开始自动识别 ↗';
  $('start').disabled = s.selecting;
  $('once').disabled = s.phase === 'solving' || s.selecting;
  $('region-badge').textContent = s.config.region ? '已框选' : '未设置';
  $('region-badge').classList.toggle('mint', !!s.config.region);
  $('region-button-text').textContent = s.config.region ? '重新框选区域' : '框选题目区域';
  $('region-description').textContent = s.config.region ? s.config.region.width + ' × ' + s.config.region.height + ' · 逻辑像素' : '尚未框选 · 支持多显示器';
  $('display-description').textContent = s.config.region ? s.displays.find(d => d.id === s.config.displayId)?.label || '' : '';
  $('preview').disabled = !s.config.region;
  toggle('click-through', s.config.clickThrough); toggle('overlay-toggle', s.overlayVisible);
  const visibleAnswer = s.answer && s.answer !== '[[NO_QUESTION]]' && !'[[NO_QUESTION]]'.startsWith(s.answer);
  $('answer-empty').hidden = !!visibleAnswer; $('answer-content').hidden = !visibleAnswer;
  if (s.answer !== lastAnswer) { renderAnswer($('answer-content'), visibleAnswer ? s.answer : ''); lastAnswer = s.answer; }
  $('answer-badge').textContent = s.demo ? '演示' : s.phase === 'solving' ? '生成中…' : s.answer ? '已更新' : '等待题目';
  $('answer-error').hidden = !s.error; $('answer-error').textContent = s.error;
  $('answer-meta').textContent = s.elapsedMs ? (s.elapsedMs / 1000).toFixed(1) + ' 秒 · ' + (s.demo ? '内置示例' : s.config.model) : '支持公式、代码与多道题';
  $('copy').disabled = !s.answer;
  $('capture-summary').textContent = '每 ' + s.config.intervalMs / 1000 + ' 秒检查 · 本次会话 ' + s.requests + ' 次识别请求';
  $('setup-dot').hidden = s.hasKey;
  $('key-badge').textContent = s.hasKey ? '密钥已配置' : '未配置';
  $('key-state').textContent = s.hasKey ? '已配置 · 留空保留' : '';
  $('key-storage').textContent = s.keyStorage === 'encrypted' ? '已使用系统加密保存，仅当前 Windows 用户可读取' : s.keyStorage === 'session' ? '加密存储不可用：密钥只在本次会话中保留' : '密钥优先使用 Windows 加密存储';
  $('clear-key').disabled = !s.hasKey;
  const notices = [s.startupNotice, s.shortcutWarnings.length ? s.shortcutWarnings.join('；') + '。' : ''].filter(Boolean);
  $('notice').hidden = !notices.length; $('notice').textContent = notices.join(' ');
  for (const [index, name] of ['capture', 'overlay', 'clickThrough', 'region', 'dashboard'].entries()) {
    const element = document.querySelectorAll('.hotkey-row kbd')[index];
    if (s.shortcuts[name]) element.textContent = s.shortcuts[name];
  }
  document.querySelector('.shortcut-hint').textContent = (s.shortcuts.clickThrough || 'Ctrl + Alt + X') + ' · 随时切换穿透';
}
function settingsInput() { return { baseUrl: $('base-url').value, model: $('model').value, apiKey: $('api-key').value, displayId: $('display').value, intervalMs: Number($('interval').value), cooldownMs: Number($('cooldown').value), maxTokens: Number($('max-tokens').value), opacity: Number($('opacity').value) / 100 }; }
function bind(id, action) { $(id).addEventListener('click', () => Promise.resolve().then(action).catch(() => {})); }
document.querySelectorAll('.nav-item').forEach(button => button.addEventListener('click', () => switchPage(button.dataset.page)));
bind('start', async () => { if (!state.hasKey) { switchPage('settings'); $('api-key').focus(); toast('请先配置 API Key。'); return; } if (!state.config.region) { toast('请先框选题目区域。'); return; } await call('toggleCapture'); });
bind('select-region', () => call('selectRegion')); bind('click-through', () => call('toggleClickThrough')); bind('overlay-toggle', () => call('toggleOverlay'));
bind('once', () => call('captureOnce')); bind('demo', () => call('demo')); bind('copy', async () => { await call('copyAnswer'); toast('解答已复制'); });
bind('minimize', () => call('minimize')); bind('close', () => call('closeDashboard')); bind('quit', () => call('quit'));
bind('preview', async () => { const url = await call('previewCapture'); $('preview-image').src = url; $('preview-dialog').showModal(); });
bind('close-preview', () => { $('preview-dialog').close(); $('preview-image').removeAttribute('src'); });
$('preview-dialog').addEventListener('close', () => $('preview-image').removeAttribute('src'));
$('opacity').addEventListener('input', () => $('opacity-label').value = $('opacity').value + '%');
$('settings-form').addEventListener('submit', async event => { event.preventDefault(); try { const s = await call('saveSettings', settingsInput()); $('api-key').value = ''; fillSettings(s); render(s); toast('设置已保存'); } catch {} });
bind('clear-key', async () => { const s = await call('saveSettings', { clearKey: true }); $('api-key').value = ''; render(s); toast('已清除保存的 API Key'); });
bind('test-connection', async () => { $('test-connection').disabled = true; $('connection-result').textContent = '正在连接…'; try { await call('testConnection', settingsInput()); $('connection-result').textContent = '连接成功。此测试验证文本调用；截图识别需模型支持图像。'; } catch (error) { $('connection-result').textContent = error.message; } finally { $('test-connection').disabled = false; } });
api.onState(render);
call('getState').then(render).catch(() => {});
