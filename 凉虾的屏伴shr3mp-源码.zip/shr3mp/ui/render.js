'use strict';
// Keep formulas out of Markdown parsing; render them locally with KaTeX.
window.renderAnswer = (element, source) => {
  const formulas = [];
  const protectedText = source.replace(/(\$\$[\s\S]+?\$\$|\\\[[\s\S]+?\\\]|\\\([^\n]+?\\\)|(?<!\$)\$(?!\$)[^\n$]+?\$)/g, text => {
    const block = text.startsWith('$$') || text.startsWith('\\[');
    const edge = text.startsWith('\\') || block ? 2 : 1;
    const token = 'SCMATHPLACEHOLDER' + formulas.length + 'END';
    formulas.push({ token, value: text.slice(edge, -edge), block });
    return block ? '\n\n' + token + '\n\n' : token;
  });
  element.innerHTML = DOMPurify.sanitize(marked.parse(protectedText, { breaks: true, gfm: true }), {
    FORBID_TAGS: ['img', 'iframe', 'video', 'audio', 'style', 'input', 'form', 'button', 'svg'],
    FORBID_ATTR: ['style', 'src', 'srcset', 'id'],
  });
  for (const link of element.querySelectorAll('a')) link.replaceWith(...link.childNodes);
  const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
  const nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
  for (const node of nodes) {
    if (!node.nodeValue.includes('SCMATHPLACEHOLDER')) continue;
    const fragment = document.createDocumentFragment();
    const parts = node.nodeValue.split(/(SCMATHPLACEHOLDER\d+END)/);
    for (const part of parts) {
      const math = formulas.find(f => f.token === part);
      if (!math) fragment.append(document.createTextNode(part));
      else { const span = document.createElement('span'); katex.render(math.value, span, { displayMode: math.block, throwOnError: false, trust: false, strict: 'ignore', maxExpand: 1000 }); fragment.append(span); }
    }
    node.replaceWith(fragment);
  }
};
