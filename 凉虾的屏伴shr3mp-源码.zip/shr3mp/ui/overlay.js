'use strict';
const api = window.companion, $ = id => document.getElementById(id);
let lastAnswer;
function render(s) {
  $('overlay-mode').textContent = s.config.clickThrough ? '穿透中' : '可交互';
  $('overlay-mode').classList.toggle('mint', s.config.clickThrough);
  $('overlay-status-text').textContent = s.status;
  $('overlay-demo').hidden = !s.demo;
  $('overlay-pause').textContent = s.running ? '暂停识别' : '开始识别';
  const answer = s.answer && !'[[NO_QUESTION]]'.startsWith(s.answer) ? s.answer : '';
  $('overlay-empty').hidden = !!answer; $('overlay-answer').hidden = !answer;
  if (answer !== lastAnswer) { renderAnswer($('overlay-answer'), answer); lastAnswer = answer; }
  $('overlay-error').hidden = !s.error; $('overlay-error').textContent = s.error;
  $('overlay-copy').disabled = !answer;
  const key = s.shortcuts.clickThrough || 'Ctrl + Alt + X';
  $('overlay-shortcut').textContent = key + (s.config.clickThrough ? ' · 切换为可交互' : ' · 恢复穿透');
}
function bind(id, method) { $(id).addEventListener('click', async () => { const r = await api[method](); if (!r.ok) { $('overlay-error').textContent = r.error; $('overlay-error').hidden = false; } }); }
bind('overlay-copy', 'copyAnswer'); bind('overlay-pause', 'toggleCapture'); bind('overlay-settings', 'showDashboard'); bind('overlay-hide', 'toggleOverlay');
api.onState(render); api.getState().then(r => { if (r.ok) render(r.value); });
