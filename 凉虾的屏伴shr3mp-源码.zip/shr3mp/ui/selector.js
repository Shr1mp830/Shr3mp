'use strict';
const box = document.getElementById('selection-box'), size = document.getElementById('selection-size');
let start, region, submitting = false;
document.addEventListener('pointerdown', event => {
  if (event.button !== 0 || submitting) return;
  start = { x: event.clientX, y: event.clientY }; region = null; box.hidden = false;
  box.style.left = start.x + 'px'; box.style.top = start.y + 'px'; box.style.width = '0'; box.style.height = '0';
  document.body.setPointerCapture(event.pointerId);
});
document.addEventListener('pointermove', event => {
  if (!start || submitting) return;
  const x = Math.max(0, Math.min(innerWidth, event.clientX)), y = Math.max(0, Math.min(innerHeight, event.clientY));
  region = { x: Math.min(x, start.x), y: Math.min(y, start.y), width: Math.abs(x - start.x), height: Math.abs(y - start.y) };
  for (const key of ['width', 'height']) box.style[key] = region[key] + 'px';
  box.style.left = region.x + 'px'; box.style.top = region.y + 'px';
  size.textContent = Math.round(region.width) + ' × ' + Math.round(region.height);
});
document.addEventListener('pointerup', async () => {
  if (!start || submitting) return; start = null;
  if (!region || region.width < 40 || region.height < 40) { box.hidden = true; document.getElementById('selection-error').textContent = '选区至少为 40 × 40'; return; }
  submitting = true;
  const result = await window.companion.commitRegion(region);
  if (!result.ok) { submitting = false; document.getElementById('selection-error').textContent = result.error; }
});
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !submitting) window.companion.cancelRegion(); });
