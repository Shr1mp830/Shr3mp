// Receive a setup key through the child environment. Never print or store it in plaintext.
const { app, safeStorage } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const { validateConfig } = require('../src/core');
app.setName('凉虾的屏伴shr3mp');
app.setPath('userData', path.join(app.getPath('appData'), 'ScreenCompanion'));
(async () => {
  try {
    const data = { apiKey: process.env.SCREEN_COMPANION_SETUP_KEY, config: {} };
    delete process.env.SCREEN_COMPANION_SETUP_KEY;
    if (!data.apiKey) throw new Error('没有收到待配置的密钥');
    await app.whenReady();
    if (!safeStorage.isEncryptionAvailable()) throw new Error('系统加密存储不可用');
    const config = validateConfig(data.config);
    const keyEncrypted = safeStorage.encryptString(data.apiKey).toString('base64');
    data.apiKey = '';
    const directory = app.getPath('userData');
    fs.mkdirSync(directory, { recursive: true });
    const temporary = path.join(directory, 'settings.json.tmp');
    fs.writeFileSync(temporary, JSON.stringify({ config, keyEncrypted }, null, 2), { mode: 0o600 });
    fs.renameSync(temporary, path.join(directory, 'settings.json'));
    console.log('本机配置已加密保存。');
    app.quit();
  } catch (error) { console.error('配置失败：' + error.message); app.exit(1); }
})();
