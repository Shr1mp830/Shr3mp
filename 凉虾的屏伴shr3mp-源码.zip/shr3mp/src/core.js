'use strict';
const DEFAULTS = Object.freeze({
  baseUrl: 'https://maas.qianwenaiapi.com/compatible-mode/v1', model: 'qwen3.8-max',
  intervalMs: 1800, cooldownMs: 8000, maxTokens: 4096, timeoutMs: 90000,
  displayId: null, region: null, clickThrough: true, opacity: 0.96,
});
function completionUrl(value) {
  let url;
  try { url = new URL(String(value).trim()); } catch { throw new Error('API 地址格式不正确。'); }
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && local)) throw new Error('API 地址需要使用 HTTPS；本机服务可以使用 HTTP。');
  if (url.username || url.password || url.search || url.hash) throw new Error('API 地址不能包含账号、查询参数或锚点。');
  url.pathname = url.pathname.replace(/\/+$/, '');
  if (!url.pathname.endsWith('/chat/completions')) url.pathname += '/chat/completions';
  return url.toString();
}
function bounded(value, min, max, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}
function validateConfig(input = {}) {
  const baseUrl = String(input.baseUrl ?? DEFAULTS.baseUrl).trim();
  completionUrl(baseUrl);
  const model = String(input.model ?? DEFAULTS.model).trim();
  if (!model || model.length > 160) throw new Error('请填写有效的视觉模型名称。');
  const region = input.region;
  if (region != null && (!['x', 'y', 'width', 'height'].every(k => Number.isFinite(region[k])) || region.x < 0 || region.y < 0 || region.width < 40 || region.height < 40)) throw new Error('截图区域无效，请重新框选。');
  return {
    baseUrl, model,
    intervalMs: Math.round(bounded(input.intervalMs ?? DEFAULTS.intervalMs, 1000, 10000, DEFAULTS.intervalMs)),
    cooldownMs: Math.round(bounded(input.cooldownMs ?? DEFAULTS.cooldownMs, 3000, 60000, DEFAULTS.cooldownMs)),
    maxTokens: Math.round(bounded(input.maxTokens ?? DEFAULTS.maxTokens, 512, 16384, DEFAULTS.maxTokens)),
    timeoutMs: Math.round(bounded(input.timeoutMs ?? DEFAULTS.timeoutMs, 10000, 180000, DEFAULTS.timeoutMs)),
    displayId: input.displayId == null ? null : String(input.displayId),
    region: region == null ? null : { x: Math.round(region.x), y: Math.round(region.y), width: Math.round(region.width), height: Math.round(region.height) },
    clickThrough: input.clickThrough !== false,
    opacity: bounded(input.opacity ?? DEFAULTS.opacity, 0.55, 1, DEFAULTS.opacity),
  };
}
function cropBounds(image, display, region) {
  const r = region || { x: 0, y: 0, width: display.width, height: display.height };
  if (r.x < 0 || r.y < 0 || r.x + r.width > display.width + 1 || r.y + r.height > display.height + 1) throw new Error('屏幕布局已变化，请重新框选题目区域。');
  const sx = image.width / display.width, sy = image.height / display.height;
  const x = Math.max(0, Math.round(r.x * sx)), y = Math.max(0, Math.round(r.y * sy));
  const width = Math.min(image.width - x, Math.round(r.width * sx));
  const height = Math.min(image.height - y, Math.round(r.height * sy));
  if (width < 2 || height < 2) throw new Error('截图区域太小，请重新框选。');
  return { x, y, width, height };
}
function frameChanged(a, b) {
  if (!a || !b || a.length !== b.length) return true;
  let total = 0, changed = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = Math.abs(a[i] - b[i]); total += diff; if (diff > 22) changed++;
  }
  return total / a.length > 1.8 || changed / a.length > 0.0025;
}
class StableFrames {
  constructor() { this.reset(); }
  reset() { this.previous = null; this.accepted = null; }
  observe(frame) {
    const stable = this.previous && !frameChanged(this.previous, frame);
    this.previous = frame;
    return Boolean(stable && frameChanged(this.accepted, frame));
  }
  accept(frame) { this.accepted = frame; }
}
function redact(message, key) {
  let result = String(message);
  if (key) result = result.split(key).join('[已隐藏密钥]');
  return result.replace(/Bearer\s+\S+/gi, 'Bearer [已隐藏]').slice(0, 650);
}
module.exports = { DEFAULTS, completionUrl, validateConfig, cropBounds, frameChanged, StableFrames, redact };
