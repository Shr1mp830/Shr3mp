const { contextBridge, ipcRenderer } = require('electron');
const invoke = channel => (...args) => ipcRenderer.invoke(channel, ...args);
contextBridge.exposeInMainWorld('companion', {
  getState: invoke('state:get'), saveSettings: invoke('settings:save'), testConnection: invoke('connection:test'),
  selectRegion: invoke('region:select'), commitRegion: invoke('region:commit'), cancelRegion: invoke('region:cancel'),
  toggleCapture: invoke('capture:toggle'), captureOnce: invoke('capture:once'), previewCapture: invoke('capture:preview'),
  toggleClickThrough: invoke('overlay:click-through'), toggleOverlay: invoke('overlay:toggle'),
  showDashboard: invoke('dashboard:show'), closeDashboard: invoke('dashboard:close'), minimize: invoke('dashboard:minimize'),
  demo: invoke('demo:show'), copyAnswer: invoke('answer:copy'), quit: invoke('app:quit'),
  onState: callback => { const handler = (_event, state) => callback(state); ipcRenderer.on('state', handler); return () => ipcRenderer.removeListener('state', handler); },
});
