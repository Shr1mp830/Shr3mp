'use strict';
const { app, BrowserWindow, ipcMain, screen, desktopCapturer, globalShortcut, Tray, Menu, nativeImage, safeStorage, clipboard, session } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { DEFAULTS, validateConfig, cropBounds, StableFrames, redact } = require('./core');
const { requestQwen } = require('./qwen');

app.setName('凉虾的屏伴shr3mp');
app.setPath('userData', process.env.SCREEN_COMPANION_TEST_PROFILE ? path.resolve(process.env.SCREEN_COMPANION_TEST_PROFILE) : path.join(app.getPath('appData'), 'ScreenCompanion'));
const ownInstance = app.requestSingleInstanceLock();
if (!ownInstance) app.quit();
let dashboard, overlay, selector, tray, timer, controller;
let config = { ...DEFAULTS }, apiKey = '', keyEncrypted = '', startupNotice = '';
let generation = 0, busy = false, selecting = false, nextRequestAt = 0;
const stability = new StableFrames();
const runtime = { running: false, phase: 'idle', status: '准备就绪', answer: '', error: '', requests: 0, updatedAt: null, elapsedMs: 0, demo: false, shortcutWarnings: [], shortcuts: {} };
const preload = path.join(__dirname, 'preload.js');
const uiRoot = path.join(__dirname, '..', 'ui');
const settingsPath = () => path.join(app.getPath('userData'), 'settings.json');
const live = win => win && !win.isDestroyed();

function loadSettings() {
  if (!fs.existsSync(settingsPath())) return;
  try {
    const saved = JSON.parse(fs.readFileSync(settingsPath(), 'utf8'));
    config = validateConfig(saved.config);
    if (saved.keyEncrypted) {
      if (safeStorage.isEncryptionAvailable()) {
        apiKey = safeStorage.decryptString(Buffer.from(saved.keyEncrypted, 'base64')); keyEncrypted = saved.keyEncrypted;
      } else startupNotice = '本机加密存储暂不可用，请重新输入 API Key。';
    }
  } catch { startupNotice = '原设置无法读取，请重新配置 API 和截图区域。'; }
}
function persist(nextConfig = config, nextEncrypted = keyEncrypted) {
  fs.mkdirSync(app.getPath('userData'), { recursive: true });
  const temporary = settingsPath() + '.tmp';
  fs.writeFileSync(temporary, JSON.stringify({ config: nextConfig, keyEncrypted: nextEncrypted }, null, 2), { mode: 0o600 });
  fs.renameSync(temporary, settingsPath());
}
function displays() {
  return screen.getAllDisplays().map((d, i) => ({ id: String(d.id), label: d.label || '显示器 ' + (i + 1), width: d.bounds.width, height: d.bounds.height, scaleFactor: d.scaleFactor }));
}
function currentDisplay() {
  const all = screen.getAllDisplays();
  if (config.displayId == null) return screen.getPrimaryDisplay();
  const found = all.find(d => String(d.id) === String(config.displayId));
  if (!found) throw new Error('所选显示器已断开，请重新选择显示器并框选。');
  return found;
}
function snapshot() {
  return { ...runtime, config, hasKey: Boolean(apiKey), keyStorage: keyEncrypted ? 'encrypted' : apiKey ? 'session' : 'none', startupNotice, displays: displays(), overlayVisible: Boolean(live(overlay) && overlay.isVisible()), selecting };
}
function broadcast() {
  const state = snapshot();
  for (const win of [dashboard, overlay]) if (live(win) && !win.webContents.isDestroyed()) win.webContents.send('state', state);
}
function status(text, phase = runtime.phase) { runtime.status = text; runtime.phase = phase; broadcast(); }
function secureWindow(win, file) {
  win.setContentProtection(true);
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', event => event.preventDefault());
  win.loadFile(path.join(uiRoot, file));
}
function showDashboard() {
  if (!live(dashboard)) return;
  if (dashboard.isMinimized()) dashboard.restore();
  dashboard.show(); dashboard.focus();
}
function createDashboard() {
  const area = screen.getPrimaryDisplay().workArea;
  dashboard = new BrowserWindow({ width: Math.min(1150, area.width - 40), height: Math.min(850, area.height - 40), minWidth: 820, minHeight: 600, show: false, frame: false, backgroundColor: '#f4f5f9', title: '凉虾的屏伴shr3mp · Qwen 屏幕助手', icon: path.join(__dirname, '../assets/icon.png'), webPreferences: { preload, contextIsolation: true, nodeIntegration: false, sandbox: true } });
  secureWindow(dashboard, 'index.html');
  dashboard.once('ready-to-show', () => dashboard.show());
  dashboard.on('close', event => { if (!app.isQuitting) { event.preventDefault(); dashboard.hide(); } });
}
function positionOverlay() {
  if (!live(overlay)) return;
  const area = currentDisplay().workArea;
  const width = Math.min(400, Math.max(300, Math.floor(area.width * 0.29)));
  overlay.setBounds({ x: area.x + area.width - width - 18, y: area.y + 18, width, height: Math.max(300, area.height - 36) });
}
function applyOverlay() {
  if (!live(overlay)) return;
  overlay.setIgnoreMouseEvents(config.clickThrough, { forward: true });
  overlay.setFocusable(!config.clickThrough);
  overlay.setOpacity(config.opacity);
}
function createOverlay() {
  overlay = new BrowserWindow({ width: 390, height: 700, show: false, frame: false, transparent: true, hasShadow: false, alwaysOnTop: true, skipTaskbar: true, focusable: false, resizable: false, webPreferences: { preload, contextIsolation: true, nodeIntegration: false, sandbox: true } });
  overlay.setAlwaysOnTop(true, 'floating');
  secureWindow(overlay, 'overlay.html');
  try { positionOverlay(); } catch {}
  applyOverlay();
  overlay.on('close', event => { if (!app.isQuitting) { event.preventDefault(); overlay.hide(); broadcast(); } });
}
function showOverlay() { applyOverlay(); overlay.showInactive(); broadcast(); }
function toggleOverlay() { if (overlay.isVisible()) overlay.hide(); else showOverlay(); broadcast(); }
function toggleClickThrough() { config.clickThrough = !config.clickThrough; persist(); applyOverlay(); broadcast(); return config.clickThrough; }

function stopCapture(message = '已暂停', keepError = false) {
  runtime.running = false; generation++; clearTimeout(timer); timer = null;
  controller?.abort(); controller = null; stability.reset(); nextRequestAt = 0;
  if (!keepError) runtime.error = '';
  status(message, keepError ? 'error' : 'paused');
}
function requireReady() {
  if (!apiKey) throw new Error('请先在模型设置中填写 API Key。');
  if (!config.region) throw new Error('请先框选题目区域。');
  if (selecting) throw new Error('请先完成区域选择。');
  currentDisplay();
}
function scheduleTick(delay = config.intervalMs) {
  clearTimeout(timer);
  if (runtime.running) timer = setTimeout(async () => { await tick(false); if (runtime.running) scheduleTick(); }, delay);
}
function toggleCapture() {
  if (runtime.running) { stopCapture(); return; }
  requireReady(); runtime.error = ''; runtime.demo = false; runtime.running = true; stability.reset(); nextRequestAt = 0;
  showOverlay(); status('等待画面稳定', 'watching'); scheduleTick(10);
}
async function captureRegion() {
  const display = currentDisplay();
  const all = screen.getAllDisplays();
  const maxWidth = Math.min(7680, Math.max(...all.map(d => Math.ceil(d.bounds.width * d.scaleFactor))));
  const maxHeight = Math.min(4320, Math.max(...all.map(d => Math.ceil(d.bounds.height * d.scaleFactor))));
  const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: maxWidth, height: maxHeight } });
  const source = sources.find(s => s.display_id === String(display.id)) || (all.length === 1 && sources.length === 1 ? sources[0] : null);
  if (!source || source.thumbnail.isEmpty()) throw new Error('无法读取屏幕，请检查屏幕录制权限或重新选择显示器。');
  let shot = source.thumbnail.crop(cropBounds(source.thumbnail.getSize(), display.bounds, config.region));
  const tiny = shot.resize({ width: 320, height: 240, quality: 'good' }).toBitmap();
  const fingerprint = new Uint8Array(tiny.length / 4);
  for (let i = 0; i < fingerprint.length; i++) fingerprint[i] = Math.round((tiny[i * 4] + tiny[i * 4 + 1] + tiny[i * 4 + 2]) / 3);
  const size = shot.getSize();
  if (Math.max(size.width, size.height) > 2400) shot = size.width >= size.height ? shot.resize({ width: 2400, quality: 'best' }) : shot.resize({ height: 2400, quality: 'best' });
  return { fingerprint, dataUrl: 'data:image/jpeg;base64,' + shot.toJPEG(88).toString('base64') };
}
async function tick(force) {
  if (busy) { if (force) throw new Error('正在识别，请稍候或先暂停。'); return; }
  if (!force && (!runtime.running || Date.now() < nextRequestAt)) return;
  requireReady(); busy = true;
  const ticket = generation;
  try {
    const frame = await captureRegion();
    if (ticket !== generation) return;
    const ready = stability.observe(frame.fingerprint);
    if (!force && !ready) { status('监听中 · 等待新题稳定', 'watching'); return; }
    controller = new AbortController(); runtime.error = ''; runtime.answer = ''; runtime.demo = false; runtime.elapsedMs = 0;
    runtime.requests++; showOverlay(); status('正在识别并解题…', 'solving');
    const start = Date.now(); let lastUpdate = 0;
    const result = await requestQwen({ config, key: apiKey, imageUrl: frame.dataUrl, signal: controller.signal, onText: text => {
      if (ticket !== generation) return;
      runtime.answer = text; runtime.elapsedMs = Date.now() - start;
      if (Date.now() - lastUpdate > 90) { broadcast(); lastUpdate = Date.now(); }
    } });
    if (ticket !== generation) return;
    runtime.elapsedMs = Date.now() - start; runtime.updatedAt = Date.now();
    stability.accept(frame.fingerprint); nextRequestAt = Date.now() + config.cooldownMs;
    if (result.trim() === '[[NO_QUESTION]]') { runtime.answer = ''; status('当前区域未发现题目', runtime.running ? 'watching' : 'idle'); }
    else { runtime.answer = result; status(runtime.running ? '答案已更新 · 继续监听' : '识别完成', runtime.running ? 'watching' : 'idle'); }
  } catch (error) {
    if (ticket !== generation || error.name === 'AbortError') return;
    runtime.error = redact(error.message, apiKey);
    stopCapture('识别失败 · 已暂停', true);
  } finally { busy = false; if (ticket === generation) controller = null; }
}

function finishSelection() {
  selecting = false;
  if (live(selector)) { selector.destroy(); selector = null; }
  showDashboard(); broadcast();
}
function selectRegion() {
  if (selecting) return;
  const display = currentDisplay();
  stopCapture('选择题目区域'); selecting = true;
  dashboard.hide(); overlay.hide();
  selector = new BrowserWindow({ ...display.bounds, frame: false, transparent: true, resizable: false, movable: false, skipTaskbar: true, alwaysOnTop: true, enableLargerThanScreen: true, webPreferences: { preload, contextIsolation: true, nodeIntegration: false, sandbox: true } });
  selector.setAlwaysOnTop(true, 'screen-saver');
  secureWindow(selector, 'selector.html');
  selector.once('ready-to-show', () => { selector.show(); selector.focus(); });
  selector.on('closed', () => { selector = null; selecting = false; broadcast(); });
  broadcast();
}
function commitRegion(region) {
  if (!selecting) throw new Error('当前没有待确认的选区。');
  const d = currentDisplay();
  const next = validateConfig({ ...config, region, displayId: String(d.id) });
  cropBounds(d.bounds, d.bounds, next.region);
  persist(next); config = next; stability.reset(); finishSelection(); positionOverlay(); status('区域已就绪，可以开始识别', 'idle');
}
function saveSettings(input) {
  if (!input || typeof input !== 'object') throw new Error('设置格式不正确。');
  const newDisplay = String(input.displayId ?? config.displayId ?? screen.getPrimaryDisplay().id);
  const next = validateConfig({ ...config, ...input, displayId: newDisplay, region: newDisplay !== String(config.displayId ?? screen.getPrimaryDisplay().id) ? null : config.region });
  if (!displays().some(d => d.id === newDisplay)) throw new Error('所选显示器不可用。');
  let nextKey = apiKey, nextEncrypted = keyEncrypted;
  if (input.clearKey) { nextKey = ''; nextEncrypted = ''; }
  else if (typeof input.apiKey === 'string' && input.apiKey.trim()) {
    nextKey = input.apiKey.trim();
    if (nextKey.length > 8192 || /[\r\n]/.test(nextKey)) throw new Error('API Key 格式不正确。');
    nextEncrypted = safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(nextKey).toString('base64') : '';
  }
  persist(next, nextEncrypted); stopCapture('设置已保存'); config = next; apiKey = nextKey; keyEncrypted = nextEncrypted;
  applyOverlay(); positionOverlay(); broadcast(); return snapshot();
}
let testingConnection = false;
async function testConnection(input) {
  if (testingConnection) throw new Error('连接测试正在进行。');
  const next = validateConfig({ ...config, ...input, region: config.region });
  const key = input?.apiKey?.trim() || apiKey;
  if (!key) throw new Error('请先填写 API Key。');
  testingConnection = true;
  try { return await requestQwen({ config: next, key, testOnly: true }); }
  finally { testingConnection = false; }
}
function demo() {
  stopCapture('演示答案 · 未调用 API'); runtime.demo = true; runtime.error = ''; runtime.elapsedMs = 1240;
  runtime.answer = '### 答案\n方程的两个解为 **x = 2** 和 **x = 3**。\n\n### 解题步骤\n1. 将二次多项式因式分解：\n\n$$x^2 - 5x + 6 = (x - 2)(x - 3)$$\n\n2. 由 $(x - 2)(x - 3) = 0$，得到 $x = 2$ 或 $x = 3$。\n\n3. 代回原式，两组解均成立。\n\n### 题目识别\n求解方程 $x^2 - 5x + 6 = 0$。\n\n> 这是内置演示，用于检查答案窗和公式显示。';
  showOverlay(); broadcast();
}
function handle(channel, allowedFiles, callback) {
  ipcMain.handle(channel, async (event, ...args) => {
    const allowed = allowedFiles.map(f => pathToFileURL(path.join(uiRoot, f)).href);
    if (!allowed.includes(event.senderFrame?.url)) return { ok: false, error: '不允许的操作来源。' };
    try { return { ok: true, value: await callback(...args) }; }
    catch (error) { return { ok: false, error: redact(error.message, apiKey) }; }
  });
}
function registerIPC() {
  const main = ['index.html'], both = ['index.html', 'overlay.html'];
  handle('state:get', [...both, 'selector.html'], snapshot);
  handle('settings:save', main, saveSettings); handle('connection:test', main, testConnection);
  handle('region:select', main, selectRegion); handle('region:commit', ['selector.html'], commitRegion); handle('region:cancel', ['selector.html'], finishSelection);
  handle('capture:toggle', both, toggleCapture);
  handle('capture:once', both, async () => { requireReady(); await tick(true); });
  handle('capture:preview', main, async () => { if (!config.region || selecting) throw new Error('请先框选题目区域。'); return (await captureRegion()).dataUrl; });
  handle('overlay:click-through', both, toggleClickThrough); handle('overlay:toggle', both, toggleOverlay);
  handle('dashboard:show', both, showDashboard); handle('dashboard:close', main, () => dashboard.hide()); handle('dashboard:minimize', main, () => dashboard.minimize());
  handle('demo:show', main, demo); handle('answer:copy', both, () => { clipboard.writeText(runtime.answer); }); handle('app:quit', main, () => app.quit());
}
function shortcut(action) {
  return () => { try { action(); } catch (error) { runtime.error = error.message; broadcast(); showDashboard(); } };
}
app.on('second-instance', () => showDashboard());
app.on('window-all-closed', () => {});
app.on('before-quit', () => { app.isQuitting = true; clearTimeout(timer); controller?.abort(); globalShortcut.unregisterAll(); });
if (ownInstance) app.whenReady().then(() => {
  app.setAppUserModelId('local.screencompanion.qwen'); loadSettings();
  if (config.displayId == null) config.displayId = String(screen.getPrimaryDisplay().id);
  registerIPC();
  session.defaultSession.setPermissionRequestHandler((_webContents, _permission, callback) => callback(false));
  createDashboard(); createOverlay();
  tray = new Tray(nativeImage.createFromPath(path.join(__dirname, '../assets/tray.png')));
  tray.setToolTip('凉虾的屏伴shr3mp · Qwen 屏幕助手');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: '打开控制台', click: showDashboard }, { label: '开始 / 暂停识别', click: shortcut(toggleCapture) },
    { label: '显示 / 隐藏答案窗', click: toggleOverlay }, { label: '切换鼠标穿透', click: shortcut(toggleClickThrough) },
    { type: 'separator' }, { label: '退出凉虾的屏伴shr3mp', click: () => app.quit() },
  ]));
  tray.on('double-click', showDashboard);
  for (const [id, letter, label, action] of [
    ['capture', 'S', '开始 / 暂停', toggleCapture], ['overlay', 'A', '显示 / 隐藏答案', toggleOverlay],
    ['clickThrough', 'X', '鼠标穿透', toggleClickThrough], ['region', 'R', '框选题目', selectRegion], ['dashboard', 'O', '控制台', showDashboard],
  ]) {
    const preferred = 'CommandOrControl+Alt+' + letter;
    const fallback = 'CommandOrControl+Alt+Shift+' + letter;
    if (globalShortcut.register(preferred, shortcut(action))) runtime.shortcuts[id] = 'Ctrl + Alt + ' + letter;
    else if (globalShortcut.register(fallback, shortcut(action))) {
      runtime.shortcuts[id] = 'Ctrl + Alt + Shift + ' + letter;
      runtime.shortcutWarnings.push(label + '已改用 ' + runtime.shortcuts[id]);
    } else { runtime.shortcuts[id] = '未注册 · 请用托盘'; runtime.shortcutWarnings.push(label + '快捷键被占用，请使用托盘菜单'); }
  }
  const displayChanged = () => { stopCapture('显示器布局变化，请重新框选'); config.region = null; try { persist(); positionOverlay(); } catch {} broadcast(); };
  screen.on('display-removed', displayChanged); screen.on('display-metrics-changed', displayChanged); screen.on('display-added', () => broadcast());
  app.on('activate', showDashboard);
}).catch(error => { console.error('启动失败：', error.message); app.exit(1); });
